import json
import boto3

stockdetails=''
POI='False'
kinesis_client = boto3.client("kinesis", "us-east-1")
ShardIteratorresponse1 = kinesis_client.get_shard_iterator(
ShardId='shardId-000000000000',
StreamName='CloudFormationProject1',
ShardIteratorType='LATEST'
)
record_response = kinesis_client.get_records(
ShardIterator=ShardIteratorresponse1['ShardIterator'],
Limit=10000
)
print(record_response)

countervalue=0
while countervalue < 3000:
    
    while 'NextShardIterator' in record_response:
        ShardIterator=record_response['NextShardIterator']
        record_response = kinesis_client.get_records(
        ShardIterator=ShardIteratorresponse1['ShardIterator'],
        Limit=10000
        )
        #print(record_response)
       
        countervalue +=1
        if(record_response['Records']):
            print (record_response)
            fiftyTwoWeekHigh=record_response['Records']['52WeekHigh']
            fiftyTwoWeekLow=record_response['Records']['52WeekLow']
            openvalue=record_response['Records']['open']
            closevalue= record_response['Records']['close']
            ticker= record_response['Records']['name']
            if(closevalue>=(80 % fiftyTwoWeekHigh) or closevalue (99 % fiftyTwoWeekLow)):
                POI = True		
                print("Point Of Intrest " +ticker )
            else:
                POI = False
            if(POI):
                dynamodb_res = boto3.resource('dynamodb', region_name='us-east-1')
                table = dynamodb_res.Table('POIDetails')
                response = table.put_item(Item={
                    'fiftyTwoWeekHigh' : record_response['Records']['52WeekHigh'],
                    'fiftyTwoWeekLow' : record_response['Records']['52WeekLow'],
                    'openvalue' : record_response['Records']['open'],
                    'closevalue' : record_response['Records']['close'],
                    'name': record_response['Records']['name'],
                    'ts' : record_response['Records']['ts']})
                print("POI Data inserted to DynamoDb")
    if (countervalue==3):    
        break
    
   
    
   